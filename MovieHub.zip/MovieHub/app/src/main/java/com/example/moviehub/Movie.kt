package com.example.moviehub

data class Movie(
    val title: String,
    val year: Int,
    val genre: String,
    val description: String
)
