package com.example.moviehub

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class DetailActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        val title = intent.getStringExtra("title") ?: "Фильм не найден"
        val year = intent.getIntExtra("year", 0)
        val genre = intent.getStringExtra("genre") ?: "Жанр не указан"
        val description = intent.getStringExtra("description") ?: "Описание отсутствует"
        findViewById<TextView>(R.id.detailTitle).text = title
        findViewById<TextView>(R.id.detailInfo).text = "$year · $genre"
        findViewById<TextView>(R.id.detailDescription).text = description
        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
    }
}
