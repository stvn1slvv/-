package com.example.moviehub

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val list: RecyclerView = findViewById(R.id.moviesList)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = MovieAdapter(MovieRepository.movies) { movie ->
            Toast.makeText(this, "Вы выбрали фильм: ${movie.title}", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, DetailActivity::class.java).apply {
                putExtra("title", movie.title)
                putExtra("year", movie.year)
                putExtra("genre", movie.genre)
                putExtra("description", movie.description)
            }
            startActivity(intent)
        }
    }
}
